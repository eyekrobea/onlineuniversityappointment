<?php ob_start();

require_once('../connect.php');
global $conn;

if($_SERVER['REQUEST_METHOD'] === "POST") {
    if(isset($_POST['lecturer_signin']) && isset($_POST['email'])) {
        $lecturer_id = trim($_POST['email']);
        $password = trim($_POST['password']);
        //$hashed_password = hash('2y$', $password); // TODO: check how to implement hash9

        // 1. connect database  ->$conn
        $sql = "SELECT `password` FROM `users` WHERE `user_id` = $lecturer_id";
        // 2. insert the incoming data to the database
        $stmt = $conn->prepare($sql);
        $result = $stmt->fetch();
        // 3. get the user data
        if($results && password_verify($password, $result['password'])){
            $sql = "SELECT * FROM `users` WHERE `user_id` = $lecturer_id";
            $result = $conn->prepare($sql)->execute();
        }
        // 4. redirect the user based on their roles to the specific dashboard
        if($result['role'] === 'lecturer') {
            header('Location: ../dashboard/lecturer-dashboard/lecturer-dashboard.php');
        } else 
            header('Location: ../sign-in.php')
        }

    } 
    else if(isset($_POST['student_signin']) && isset($_POST['email'])) {

    }
} else {
    echo 'nothing here';
}